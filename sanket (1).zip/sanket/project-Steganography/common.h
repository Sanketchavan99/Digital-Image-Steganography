/*
Name:SANKET
Date:13/01/2024
Description:common.h file
*/



#ifndef COMMON_H
#define COMMON_H

/*Magic string to identify whether stegged or not */
#define MAGIC_STRING "#*"

#endif
