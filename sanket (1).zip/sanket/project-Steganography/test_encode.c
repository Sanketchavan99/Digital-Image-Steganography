/*
Name:SANKET
Date:13/01/2024
Description:test_encode.c
*/

#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "decode.h"

int main(int argc, char *argv[])
{
    if(argc < 3)
    {
	printf("Encoding is not possible please pass more than 3 arguments\n");
	printf("Usage : ./a.out -e beautiful.bmp secret.txt\n");
	return e_failure;
    }

    char staus = check_operation_type(argv);
    if(staus == e_encode)
    {
	if( argc > 3 )
	{
	    printf("You selected Encoding\n");

	    EncodeInfo encInfo;
	    if(read_and_validate_encode_args(argv, &encInfo) == e_success)
	    {
		printf("Read and validation is success\n");
		if(do_encoding(&encInfo) == e_success)
		{
		    printf("Encoding is completed\n");
		}
	    }
	}
    }
    else if(staus == e_decode)
    {
	if(argc>2)
	{
	    printf("You selected Decoding\n");

	    Decode_Info decInfo;
	    if(read_validate_decode_args(argv, &decInfo) == d_success)
	    {
		printf("Read and validation is success\n");
		if(do_decoding(&decInfo) == d_success)
		{
		    printf("Decoding is completed\n");
		}
	    }
	}
    }


    return 0;
}

OperationType check_operation_type(char *argv[])
{
    if(strcmp(argv[1], "-e") == 0)
    {
	return e_encode;
    }
    else if(strcmp(argv[1], "-d") == 0)
    {
	return e_decode;
    }
    return e_unsupported;
}


