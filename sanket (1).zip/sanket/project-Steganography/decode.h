/*
Name       :SANKET
Date       :13/01/2024
*/


#ifndef DECODE_H
#define DECODE_H

typedef struct Decode_Info
{
    char *stego_image;
    FILE *fptr_stego_image;
    char *decode_file;
    FILE *fptr_decode_file;
    char decode_file_name[50];
    uint secret_file_size;
}Decode_Info;


/*Decoding function prototypes*/

/*Read and Validate decode args from argv*/
decode read_validate_decode_args(char *argv[], Decode_Info *decInfo);

/*Get File pointers for i/p and o/p files*/
decode Open_files(Decode_Info *decInfo);

/*perform the decoding*/
decode do_decoding(Decode_Info *decInfo);

/*Store magic string*/
decode decode_magic_string(FILE *fptr_stego_image);

/*decode secret file extension size*/
decode decode_secret_file_extn_size(Decode_Info *decInfo, FILE *fptr_stego_image);

/*decode secret file extension*/
decode decode_secret_file_extn(Decode_Info *decInfo, int extn_size, FILE *fptr_stego_image);

/*decode secret file size*/
decode decode_secret_file_size(Decode_Info *decInfo, FILE *fptr_stego_image);

/*decode secret file data*/
decode decode_secret_file_data(Decode_Info *decInfo);

#endif




