/*
Name: SANKET
Date: 13/01/2024
Description:decode.c file
*/


#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include <string.h>
#include "decode.h"

//check validation
decode read_validate_decode_args(char *argv[], Decode_Info *decInfo)
{
    if(strcmp(strstr(argv[2], "."), ".bmp") == 0)
    {
	printf("Yes!! argv[2] is file.bmp\n");
	decInfo -> stego_image = argv[2];
	if(argv[3] != NULL)
	{
	    decInfo -> decode_file = strtok(argv[3], ".");
	    printf("decode file is successfully stored\n");
	    return d_success;
	}
	else
	{
	    decInfo -> decode_file = "decode";
	    printf("decode file is successfully stored\n");
	    return d_success;
	}
    }
    else
    {
	printf("No!! argv[2] is not a .bmp file\n");
    }
    return d_failure;
}

//open files for decoding
decode Open_files(Decode_Info *decInfo)
{
    decInfo -> fptr_stego_image = fopen(decInfo -> stego_image, "r");
    if(decInfo -> fptr_stego_image == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo -> stego_image);
	return d_failure;
    }
    return d_success;
}

//decode files from lsb
decode decode_lsb_bit(char *data)
{
    *data = (*data) & 1;
    return d_success;
}


//decode magic string
decode decode_magic_string(FILE *fptr_stego_image)
{
    char magic_char = 0, buffer[MAX_IMAGE_BUF_SIZE];
    char magic_str[strlen(MAGIC_STRING)+1];
    fseek(fptr_stego_image, 54L, SEEK_SET);
    for(int i=0; i<strlen(MAGIC_STRING); i++)
    {
	magic_char = 0;
	fread(&buffer, sizeof(char), 8, fptr_stego_image);
       	for(int j=0; j<8; j++)
	{
	    decode_lsb_bit(&buffer[j]);
	    magic_char = (buffer[j] << j) | magic_char;
	}
	magic_str[i] = magic_char;
	magic_char = 0;
    }
    magic_str[strlen(MAGIC_STRING)] ='\0';
    if(strcmp(magic_str, MAGIC_STRING) == 0)
    {
	printf("Magic strings are equal, data is encrypted in the image\n");
    }
    else
    {
	printf("Magic strings are not equal, data is not encrypted in the image\n");
	return d_failure;
    }
    return d_success;
}


//decode secret file extention
decode decode_secret_file_extn(Decode_Info *decInfo, int extn_size, FILE *fptr_stego_image)
{
    char buffer[MAX_IMAGE_BUF_SIZE], file_extn[extn_size], extn_char = 0;
    for(int i=0; i<extn_size; i++)
    {
	fread(&buffer, sizeof(char), MAX_IMAGE_BUF_SIZE, fptr_stego_image);
	for(int j=0; j<MAX_IMAGE_BUF_SIZE; j++)
	{
	    decode_lsb_bit(&buffer[j]);
	    extn_char = (buffer[j] << j) | extn_char;
	}
	file_extn[i] = extn_char;
	extn_char = 0;
    }
    file_extn[extn_size] ='\0';
    strcpy(decInfo -> decode_file_name, decInfo -> decode_file);
    strcat(decInfo -> decode_file_name, file_extn);
    decInfo -> fptr_decode_file = fopen(decInfo -> decode_file_name, "w");

    if(decInfo -> fptr_decode_file == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo -> decode_file_name);
	return d_failure;
    }
    return d_success;
}


//decode secret file extention size
decode decode_secret_file_extn_size(Decode_Info *decInfo, FILE *fptr_stego_image)
{
    char buffer[32];
    int extn_size=0;
    fread(&buffer, sizeof(char), 32, fptr_stego_image);
    for(int i=0; i<32; i++)
    {
	decode_lsb_bit(&buffer[i]);
	extn_size = ((int)buffer[i] << i) | extn_size;
    }
    if(decode_secret_file_extn(decInfo, extn_size, fptr_stego_image) == d_success)
    {
	printf("Secret file extension is been decoded successfully and attached extension to the file\n");
    }
    return d_success;
}



//decode secret file size
decode decode_secret_file_size(Decode_Info *decInfo, FILE *fptr_stego_image)
{
    char buffer[32];
    int secret_file_size = 0;
    fread(&buffer, sizeof(char), 32, fptr_stego_image);
    for(int i=0; i<32; i++)
    {
	decode_lsb_bit(&buffer[i]);
	secret_file_size = ((int)buffer[i] << i) | secret_file_size;
    }
    decInfo -> secret_file_size = secret_file_size;
    return d_success;
}

//decode secret file data
decode decode_secret_file_data(Decode_Info *decInfo)
{
    char buffer[MAX_IMAGE_BUF_SIZE], file_data = 0;
    for(int i=0; i < decInfo -> secret_file_size; i++)
    {
        fread(&buffer, sizeof(char), MAX_IMAGE_BUF_SIZE, decInfo -> fptr_stego_image);
        for(int j=0; j < MAX_IMAGE_BUF_SIZE; j++)
	{
	   decode_lsb_bit(&buffer[j]);
           file_data = (buffer[j] << j) | file_data;
        }
        fwrite(&file_data, sizeof(char), 1, decInfo -> fptr_decode_file);
        file_data=0;
    }
//    fcloseall();

    return d_success;
}


//decode do decoding
decode do_decoding(Decode_Info *decInfo)
{
    if(Open_files(decInfo) == d_success)
    {
	printf("Encrypted file is opened successfully\n");
	if(decode_magic_string(decInfo -> fptr_stego_image) == d_success)
	{
	    printf("Magic string is decoded successfully\n");
	    if(decode_secret_file_extn_size(decInfo, decInfo -> fptr_stego_image) == d_success)
	    {
		if(decode_secret_file_size(decInfo, decInfo -> fptr_stego_image) == d_success)
		{
		    printf("Secret file size is decrypted successfully\n");
		    if(decode_secret_file_data(decInfo) == d_success)
		    {
			printf("Decryption of data to file is done successfully\n");
			return d_success;
		    }
		}
	    }
	}
    }
    fclose(decInfo->fptr_stego_image);
}

